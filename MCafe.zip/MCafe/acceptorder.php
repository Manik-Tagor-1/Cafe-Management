<?php
include('inc/header.php');
error_reporting(0);
?>
<?php
include 'lib/Session.php';
Session::checkUserSession();
$tableName = Session::get("tableName");
?>
<?php include 'classes/Payment.php';
$pay = new Payment();
?>
<?php
	if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['Verify'])) {
	$verifyPayment = $pay->verifyPayment($_POST, $tableName);
	}
?>
<?php
include 'classes/Category.php';
$cat = new Category();
?>
<?php include 'classes/Product.php';
$pro = new Product();
?>
<?php include 'classes/Order.php';
$order = new Order();
?>
<?php include 'inc/mainnav.php'; ?>
<div class="row">
	<div class="container-fluid">
		
		<?php include('inc/categoryinc.php');?>
		<div class="col-md-7" style="min-height: 480px;">
			<div class="panel panel-default">
				<div class="panel-heading text-center" style="font-size: 20px; font-weight: bolder;">Your Ordered Products</div>
				<div class="panel-body">
					<?php if (isset($verifyPayment)) {
						echo $verifyPayment;
					} ?>
					<div class="table-responsive">
						<table class="table table-striped table-bordered table-hover" id="dataTables-example">
							<thead>
								
								<tr style="width: 100%;">
									<th colspan="6" class="text-center">Ordered Product</th>
								</tr>
								<tr style="width: 100%;">
									<th class="text-center">SL</th>
									<th class="text-center">Table Name</th>
									<th class="text-center">Product Name</th>
									<th class="text-center">Quantity</th>
									<th class="text-center">Price</th>
								</tr>
							</thead>
							<tbody>
								
								<?php
								
									$getAcceptedOrder = $order->getAcceptedOrder($tableName);
									if($getAcceptedOrder){
										$i=0;
										$sum=0;
									while ($row = $getAcceptedOrder->fetch_assoc()) {
										$i++;
								?>
								<tr class="odd gradeX" style="width: 100%;">
									<td class="text-center"><?php echo $i; ?></td>
									<td class="center"><?php echo $row['tableName']; ?></td>
									<td class="center"><?php echo $row['productName']; ?></td>
									<td class="text-center"><?php echo $row['Quantity']; ?></td>
									<td class="text-center"><?php echo $total = $row['ProPrice']; ?></td>
									<?php $sum = $sum+$total; ?>
								</tr>
								<?php	} }?>
								<tr class="odd gradeX" style="width: 100%;">
									<td class="text-center" colspan="4" class="text-right">Total:</td>
									<td colspan="" rowspan="" headers="" class="text-center"><?php echo $sumtotal = $sum; ?></td>
									
								</tr>
								<?php if ($sumtotal > '0'){ ?>
								<tr>
									<td class="text-center" colspan="5">
										<a class="btn btn-warning btn-sm" data-toggle="modal" data-target="#exampleModal" data-whatever="@mdo">Pay Now</a>
										<div class="panel-heading text-center" style="font-size: 20px; font-weight: bolder;"><a href="" class="btn btn-warning btn-sm " data-toggle="modal" data-target="#exampleModal" data-whatever="@mdo">Add</a></div>
									</td>
								</tr>
								<?php } ?>
								
							</tbody>
						</table>
					</div>
				</div>
			</div>
		</div>
		<?php include('inc/orderpage.php');?>
		
	</div>
</div>
<?php include 'inc/footer.php'; ?>
<!-- Modal -->
<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
	<div class="modal-dialog" role="document">
		<div class="modal-content">
			<div class="modal-header">
				<h3 class="modal-title" id="exampleModalLabel">Payment <button type="button" class="close" data-dismiss="modal" aria-label="Close">
				<span aria-hidden="true">&times;</span></h3>
				
				</button>
			</div>
			
			
			<div class="modal-body">
				
				<?php if (isset($verifyPayment)) {
					echo $verifyPayment;
				} ?>
				
				<div class='alert alert-danger alert-dismissable '><b>Welcome!</b> Please pay with BKash/Rocket. BKash/Rocket number is 01756267977. After Payment <?php echo $sumtotal; ?> /- Varify your payment. Thanks for using digital service.</div>
				<form class="form-horizontal" action="" method="POST">
					
					<div class="form-group">
						<div class="col-sm-6">
							<label class="control-label" for="proname">Select Option:</label>
							
							<select name="paymethod" id="" class="form-control">
								<option value="BKash">BKash</option>
								<option value="Rocket">Rocket</option>
							</select>
						</div>
						
						<div class="col-sm-6">
							<label class="control-label" for="proname">Transection Id:</label>
							<input type="text" name="trxid" id="" placeholder="Transection Id" class="form-control">
							<input type="hidden" name="tablename" id="" placeholder="Transection Id" class="form-control" value="<?php echo $tableName; ?>">
						</div>
					</div>
					<div class="form-group">
						<div class="col-sm-6">
							<label class="control-label" for="proname">Your Phone:</label>
							<input type="text" name="phone" id="" placeholder="Enter Phone Number" class="form-control">
						</div>
						
						<div class="col-sm-6">
							<label class="control-label" for="proname">Pay Balance:</label>
							<input type="text" name="paybalance" id="" placeholder="Balance" class="form-control">
						</div>
					</div>
					<div class="modal-footer">
						<div class="col-sm-8">
							<input type="submit" name="Verify" class="btn btn-primary" value="Verify Payment">
						</div>
					</div>
				</form>
			</div>
		</div>
	</div>
</div>
<!--End  Modal -->