<?php
$filepath = realpath(dirname(__FILE__));
include_once $filepath . '/../lib/Database.php';
include_once $filepath . '/../helpers/Format.php';
?>
<?php
/**
*
*/
class Table{
	private $db;
	private $fm;
	function __construct() {
		$this->db = new Database();
		$this->fm = new Format();
	}
	/* ------- tableegory ---------*/
	public function tableInsert($data) {
		$tablename = $this->fm->validation($data['tablename']);
		$tablename = mysqli_real_escape_string($this->db->link, $tablename);
		$tablepass = $this->fm->validation(md5($data['tablepass']));
		$tablepass = mysqli_real_escape_string($this->db->link, $tablepass);
			$sql = "SELECT * FROM tables WHERE tableName = '$tablename'";
			$result1 = $this->db->select($sql);
			if ($result1 > '0') {
				$msg = "<div class='alert alert-warning alert-dismissable Cus'><b>Sorry!</b> Table is already added here. Please insert new one</div>";
				return $msg;
			}
		if ($tablename == "") {
			$msg = "<div class='alert alert-danger alert-dismissable Cus'><b>Sorry!</b> Table Name must not be empty.</div>";
			return $msg;
		}elseif($tablepass == "") {
			$msg = "<div class='alert alert-danger alert-dismissable Cus'><b>Sorry!</b> Password must not be empty.</div>";
			return $msg;
		}else{
			$query = "INSERT INTO tables(tableName, Password) VALUES('$tablename','$tablepass')";
			$tableInsert = $this->db->insert($query);
			if ($tableInsert) {
				$msg = "<div class='alert alert-success alert-dismissable Cus'><b>Success!</b> Table Inserted Successfully.</div>";
				return $msg;
			} else {
				$msg = "<div class='alert alert-danger alert-dismissable Cus'><b>Sorry!</b> Table not inserted.</div>";
				return $msg;
			}
		
	}
}
	public function allReset($tableName){
	$query = "INSERT INTO deliveryhistory(orderid, tableName, productName, ProPrice, Quantity) SELECT orderid, tableName, productName, ProPrice, Quantity FROM orderfromtable WHERE tableName='$tableName'";
	$result = $this->db->select($query);
			
	$sql = "DELETE FROM orderfromtable WHERE tableName='$tableName'";
	$result2 = $this->db->select($sql);
}
	public function getAlltable() {
		$query = "SELECT * FROM tables";
		$result = $this->db->select($query);
		return $result;
	}
	public function setAlltableTimer($tableName,$timer) {
		$query = "INSERT INTO timer(datetimenow, status, TableName) VALUES('$timer','open','$tableName')";
		$result = $this->db->select($query);
		if ($result) {
			$msg = "<div class='alert alert-success alert-dismissable Cus'><b>Success!</b> Set the time successfully.</div>";
				return $msg;
		}
		
	}
public function gettableById($editid) {
		$query = "SELECT * FROM tables WHERE id = '$editid'";
		$result = $this->db->select($query);
		return $result;
	}
	public function tableUpdate($data, $id) {
		$tablepass = $this->fm->validation(md5($data['tablepass']));
		$tablepass = mysqli_real_escape_string($this->db->link, $tablepass);
		$id = mysqli_real_escape_string($this->db->link, $id);
		if (empty($tablepass)) {
			$msg = "<div class='alert alert-warning alert-dismissable Cus'><b>Sorry!</b> Field must not be empty.</div>";
				return $msg;
		} else {
			$query = "UPDATE tables SET Password = '$tablepass' WHERE id = '$id'";
			$result = $this->db->update($query);
			if ($result) {
				$msg = "<div class='alert alert-success alert-dismissable Cus'><b>Success!</b> Password Updated Successfully.</div>";
				return $msg;
			} else {
				$msg = "<span class='error'>tableegory Not Updated!</span>";
				return $msg;
			}
		}
	}
	public function deltableById($id) {
		$query = "DELETE FROM tables WHERE id = '$id'";
		$deledata = $this->db->delete($query);
		if ($deledata) {
			$msg = "<div class='alert alert-success alert-dismissable Cus'><b>Success!</b> Table Deleted Successfully.</div>";
			return $msg;
		} else {
			$msg = "<span class='alert alert-warning' style='font-size: 16px; color: #fff;'>table Not Deleted!</span>";
			return $msg;
		}
	}
	
}
?>