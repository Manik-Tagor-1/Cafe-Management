<?php
$filepath = realpath(dirname(__FILE__));
include_once ($filepath.'/../lib/Database.php');
include_once ($filepath.'/../helpers/Format.php');
/**
* Payment Class
*/
class Payment{
	
	private $db;
	private $fm;
	
	function __construct(){
		$this->db = new Database();
		$this->fm = new Format();
	}

/* Payment */
public function verifyPayment($data){
	
	$paymethod = $this->fm->validation($data['paymethod']);
	$paymethod = mysqli_real_escape_string($this->db->link,$paymethod);
	$TableName = $this->fm->validation($data['tablename']);
	$TableName = mysqli_real_escape_string($this->db->link,$TableName);
	$trxid = $this->fm->validation($data['trxid']);
	$trxid = mysqli_real_escape_string($this->db->link,$trxid);
	$phone = $this->fm->validation($data['phone']);
	$phone = mysqli_real_escape_string($this->db->link,$phone);
	$paybalance = $this->fm->validation($data['paybalance']);
	$paybalance = mysqli_real_escape_string($this->db->link,$paybalance);

if ($paymethod = '' || $trxid = '' ||  $phone = '' ||  $paybalance = '' ) {
	$msg = "<div class='alert alert-danger alert-dismissable Cus'><b>Sorry!</b> Fields must not be empty.</div>";
	return $msg;
}else{/*
	$query = "INSERT INTO payments WHERE trxid = '$trxid'";*//*
	$query = "INSERT INTO payments(tableName) VALUES('$TableName') WHERE trxid = '$trxid'";*/
	$query = 	"UPDATE payments 
				SET 
				tableName = '$TableName' 
				WHERE trxid = '$trxid'";
	$result = $this->db->update($query);
	return $result;
}
	/*$query = "SELECT * FROM payments WHERE trxid = '$trxid'";
	$result = $this->db->select($query);
		if($result){
		$i=0;
	while ($row = $result->fetch_assoc()) {
		$i++;

		$db_paybalance = $row['payableammount'];
		$db_paymethod  = $row['payby'];
		$db_trxid      = $row['trxid'];
	}
}
if ($trxid != $db_trxid) {
	$msg = "<div class='alert alert-danger alert-dismissable Cus'><b>Sorry!</b> Transection Id missmatch.</div>";
	return $msg;
}elseif ($paymethod != $db_paymethod) {
	$msg = "<div class='alert alert-danger alert-dismissable Cus'><b>Sorry!</b> Payment Method missmatch.</div>";
	return $msg;
}elseif ($paybalance != $db_paybalance) {
	$msg = "<div class='alert alert-danger alert-dismissable Cus'><b>Sorry!</b> Payable Balance missmatch.</div>";
	return $msg;
}*/


}




	
}
?>