-- phpMyAdmin SQL Dump
-- version 4.9.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 24, 2021 at 01:01 PM
-- Server version: 10.4.8-MariaDB
-- PHP Version: 7.3.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `mcafe`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `Adminid` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `joindate` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`Adminid`, `username`, `password`, `joindate`) VALUES
(1, 'Admin', 'e10adc3949ba59abbe56e057f20f883e', '2021-03-30 07:04:56');

-- --------------------------------------------------------

--
-- Table structure for table `category`
--

CREATE TABLE `category` (
  `id` int(11) NOT NULL,
  `CatName` varchar(255) NOT NULL,
  `description` varchar(1000) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `category`
--

INSERT INTO `category` (`id`, `CatName`, `description`) VALUES
(21, 'New Category 1', 'New Category 1'),
(22, 'New Category 2', 'New Category 2'),
(23, 'New Category 3', 'New Category 3'),
(24, 'New Category 4', 'New Category 4');

-- --------------------------------------------------------

--
-- Table structure for table `deliveryhistory`
--

CREATE TABLE `deliveryhistory` (
  `hisid` int(11) NOT NULL,
  `orderid` int(11) NOT NULL,
  `tableName` varchar(255) NOT NULL,
  `productName` varchar(255) NOT NULL,
  `ProPrice` float NOT NULL,
  `Quantity` int(11) NOT NULL,
  `dated` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `deliveryhistory`
--

INSERT INTO `deliveryhistory` (`hisid`, `orderid`, `tableName`, `productName`, `ProPrice`, `Quantity`, `dated`) VALUES
(143, 163, 'Table One', 'Demo Product', 200, 5, '2021-04-16 12:02:05'),
(145, 165, 'Table One', 'Demo Product', 200, 1, '2021-04-19 02:36:08'),
(146, 166, 'Table One', 'Demo Product 34', 300, 2, '2021-04-19 02:36:08'),
(148, 167, 'Table One', 'Demo Product', 200, 2, '2021-04-19 12:27:33'),
(149, 168, 'Table One', 'Demo Product 34', 300, 2, '2021-04-19 12:27:33'),
(150, 169, 'Table One', 'Demo Product 34', 300, 1, '2021-04-19 12:27:33'),
(151, 170, 'Table One', 'Demo Product', 200, 1, '2021-04-19 12:27:33'),
(155, 171, 'Table One', 'Demo Product 34', 300, 2, '2021-04-19 12:30:43'),
(156, 172, 'Table One', 'New Product 2', 320, 2, '2021-04-19 12:30:43'),
(157, 173, 'Table One', 'Demo Product 34', 600, 2, '2021-04-19 14:41:49'),
(158, 174, 'Table One', 'Demo Product', 400, 2, '2021-04-19 14:41:49'),
(159, 175, 'Table One', 'Demo Product', 200, 1, '2021-04-19 14:41:49'),
(160, 176, 'Table One', 'New Product 2', 320, 1, '2021-04-19 14:41:49'),
(161, 177, 'Table One', 'New Product 2', 960, 3, '2021-04-19 14:41:49'),
(162, 178, 'Table One', 'Demo Product', 200, 1, '2021-04-19 14:41:49'),
(164, 179, 'Table One', 'Demo Product 34', 300, 1, '2021-04-19 15:04:36'),
(165, 180, 'Table One', 'New Product 2', 320, 1, '2021-04-19 15:04:36'),
(166, 181, 'Table One', 'Demo Product 34', 900, 3, '2021-04-19 15:04:36'),
(167, 182, 'Table One', 'Demo Product 34', 300, 1, '2021-04-19 15:04:36'),
(171, 183, 'Table One', 'Demo Product 34', 900, 3, '2021-04-19 15:09:16'),
(172, 184, 'Table One', 'New Product 2', 640, 2, '2021-04-19 15:09:16'),
(173, 185, 'Table One', 'Demo Product', 200, 1, '2021-04-19 15:09:16'),
(174, 186, 'Table One', 'Demo Product 34', 600, 2, '2021-04-19 15:14:05'),
(175, 187, 'Table One', 'New Product 2', 640, 2, '2021-04-19 15:14:05'),
(176, 188, 'Table One', 'Demo Product 34', 300, 1, '2021-04-19 15:14:05'),
(177, 189, 'Table One', 'Demo Product', 200, 1, '2021-04-19 15:14:05'),
(178, 190, 'Table One', 'New Product 2', 320, 1, '2021-04-19 15:14:05'),
(179, 191, 'Table One', 'Demo Product 34', 900, 3, '2021-04-21 03:44:48'),
(180, 192, 'Table One', 'New Product 2', 960, 3, '2021-04-21 03:44:48'),
(181, 193, 'Table One', 'Demo Product', 200, 1, '2021-04-21 03:44:48'),
(182, 194, 'Table One', 'New Product 2', 320, 1, '2021-04-21 03:44:48'),
(183, 195, 'Table One', 'New Product 2', 320, 1, '2021-04-21 03:44:48'),
(184, 196, 'Table One', 'Demo Product 34', 300, 1, '2021-04-21 03:44:48'),
(186, 197, 'Table One', 'Demo Product 34', 300, 1, '2021-04-21 03:48:36');

-- --------------------------------------------------------

--
-- Table structure for table `orderfromtable`
--

CREATE TABLE `orderfromtable` (
  `orderid` int(11) NOT NULL,
  `tableName` varchar(255) NOT NULL,
  `productName` varchar(255) NOT NULL,
  `ProPrice` float NOT NULL,
  `Quantity` int(11) NOT NULL,
  `status` varchar(11) NOT NULL,
  `deliveryReport` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `orderfromtable`
--

INSERT INTO `orderfromtable` (`orderid`, `tableName`, `productName`, `ProPrice`, `Quantity`, `status`, `deliveryReport`) VALUES
(198, 'Table One', 'Demo Product 34', 300, 1, 'Accepted', ''),
(199, 'Table One', 'Demo Product', 1000, 5, 'Denied', ''),
(200, 'Table One', 'New Product 2', 320, 1, 'Denied', ''),
(214, 'Table One', 'Demo Product 34', 300, 1, 'Denied', ''),
(215, 'Table One', 'Demo Product', 200, 1, 'Accepted', ''),
(216, 'Table One', 'Demo Product 35', 600, 2, 'Accepted', ''),
(217, 'Table One', 'New Product 3', 320, 1, 'Accepted', '');

-- --------------------------------------------------------

--
-- Table structure for table `payments`
--

CREATE TABLE `payments` (
  `id` int(11) NOT NULL,
  `tableName` varchar(255) NOT NULL,
  `payableammount` float(10,2) NOT NULL,
  `payby` varchar(255) NOT NULL,
  `trxid` varchar(255) NOT NULL,
  `verification` varchar(30) NOT NULL,
  `status` varchar(30) NOT NULL,
  `payedtime` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `payments`
--

INSERT INTO `payments` (`id`, `tableName`, `payableammount`, `payby`, `trxid`, `verification`, `status`, `payedtime`) VALUES
(1, '', 1860.00, 'BKash', 'TRX123456', '', '', '2021-04-19 21:17:16');

-- --------------------------------------------------------

--
-- Table structure for table `paymentshistory`
--

CREATE TABLE `paymentshistory` (
  `id` int(11) NOT NULL,
  `tableName` varchar(255) NOT NULL,
  `payableammount` float(10,2) NOT NULL,
  `payby` varchar(255) NOT NULL,
  `trxid` varchar(255) NOT NULL,
  `verification` varchar(30) NOT NULL,
  `status` varchar(30) NOT NULL,
  `payedtime` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `product`
--

CREATE TABLE `product` (
  `proId` int(11) NOT NULL,
  `ProName` varchar(255) NOT NULL,
  `Description` varchar(1000) NOT NULL,
  `proCat` varchar(255) NOT NULL,
  `subcat` varchar(255) NOT NULL,
  `price` float NOT NULL,
  `addedon` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `product`
--

INSERT INTO `product` (`proId`, `ProName`, `Description`, `proCat`, `subcat`, `price`, `addedon`) VALUES
(14, 'Demo Product', 'Hello product 2', 'New Category 3', '', 200, '2021-04-19 02:47:54'),
(15, 'Demo Product 34', 'Hello', 'New Category 4', '', 300, '2021-04-19 02:47:46'),
(16, 'New Product 2', '54', 'New Category 4', '', 320, '2021-04-19 11:59:02'),
(17, 'Demo Product 35', 'Hello', 'New Category 2', '', 300, '2021-04-19 02:47:46'),
(18, 'New Product 3', '54', 'New Category 1', '', 320, '2021-04-21 06:04:26');

-- --------------------------------------------------------

--
-- Table structure for table `subcategory`
--

CREATE TABLE `subcategory` (
  `id` int(11) NOT NULL,
  `sub_category` varchar(255) NOT NULL,
  `parentcat` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `subcategory`
--

INSERT INTO `subcategory` (`id`, `sub_category`, `parentcat`) VALUES
(7, 'New Sub Category 1', 'New Category 4'),
(8, 'New Sub Category 2', 'New Category 4'),
(9, 'New Sub Category 3', 'New Category 4'),
(10, 'New Sub Category 1', 'New Category 3'),
(11, 'New Sub Category 2', 'New Category 3'),
(12, 'New Sub Category 3', 'New Category 3'),
(14, 'New Sub Category 1', 'New Category 1'),
(15, 'New Sub Category 2', 'New Category 2');

-- --------------------------------------------------------

--
-- Table structure for table `tables`
--

CREATE TABLE `tables` (
  `id` int(11) NOT NULL,
  `tableName` varchar(255) NOT NULL,
  `Password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tables`
--

INSERT INTO `tables` (`id`, `tableName`, `Password`) VALUES
(23, 'Table One', 'e10adc3949ba59abbe56e057f20f883e'),
(24, 'Table Two', 'e10adc3949ba59abbe56e057f20f883e'),
(25, 'Table Three', 'e10adc3949ba59abbe56e057f20f883e'),
(26, 'Table Four', 'e10adc3949ba59abbe56e057f20f883e'),
(29, 'Table Five', 'e10adc3949ba59abbe56e057f20f883e');

-- --------------------------------------------------------

--
-- Table structure for table `timer`
--

CREATE TABLE `timer` (
  `id` int(11) NOT NULL,
  `datetimenow` datetime NOT NULL,
  `status` varchar(11) NOT NULL,
  `TableName` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `timer`
--

INSERT INTO `timer` (`id`, `datetimenow`, `status`, `TableName`) VALUES
(1, '2021-04-21 10:50:00', 'paid', 'Table One'),
(2, '2021-05-24 20:00:00', 'open', 'Table One'),
(3, '2021-05-24 19:00:00', 'open', 'Table One'),
(4, '2021-05-24 12:47:57', 'open', 'Table One'),
(5, '2021-05-24 12:47:59', 'open', 'Table Five'),
(6, '2021-05-24 12:53:16', 'open', 'Table One'),
(7, '2021-05-24 17:50:21', 'open', 'Table One'),
(8, '2021-05-24 17:05:30', 'open', 'Table Five'),
(9, '2021-05-24 17:04:54', 'open', 'Table One');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `first_name` varchar(255) NOT NULL,
  `last_name` varchar(255) NOT NULL,
  `ed` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `first_name`, `last_name`, `ed`) VALUES
(3, 'Manik Roy ', 'Tagor', 0),
(4, 'Tagor Roy', 'Manik', 0),
(5, 'Antor  ', 'Roy', 0),
(6, 'Mampi ', 'Roy', 0),
(7, 'Kawshik', 'Roy', 0),
(8, 'Nitai', 'Roy', 0),
(9, 'How', 'Are ', 0),
(10, 'Manik Roy ', 'Tagor', 0),
(11, 'Tagor Roy', 'Manik', 0),
(12, 'Antor  ', 'Roy', 0),
(13, 'Mampi ', 'Roy', 0),
(14, 'Kawshik', 'Roy', 0),
(15, 'Nitai', 'Roy', 0),
(16, 'How', 'Are ', 0),
(17, 'Manik Roy ', 'Tagor', 0),
(18, 'Tagor Roy', 'Manik', 0),
(19, 'Antor  ', 'Roy', 0),
(20, 'Mampi ', 'Roy', 0),
(21, 'Kawshik', 'Roy', 0),
(22, 'Nitai', 'Roy', 0),
(23, 'How', 'Are ', 0),
(24, 'Manik Roy ', 'Tagor', 0),
(25, 'Tagor Roy', 'Manik', 0),
(26, 'Antor  ', 'Roy', 0),
(27, 'Mampi ', 'Roy', 0),
(28, 'Kawshik', 'Roy', 0),
(29, 'Nitai', 'Roy', 0),
(30, 'How', 'Are ', 0),
(31, 'Manik Roy ', 'Tagor', 0),
(32, 'Tagor Roy', 'Manik', 0),
(33, 'Antor  ', 'Roy', 0),
(34, 'Mampi ', 'Roy', 0),
(35, 'Kawshik', 'Roy', 0),
(36, 'Nitai', 'Roy', 0),
(37, 'How', 'Are ', 0),
(38, 'Manik Roy ', 'Tagor', 0),
(39, 'Tagor Roy', 'Manik', 0),
(40, 'Antor  ', 'Roy', 0),
(41, 'Mampi ', 'Roy', 0),
(42, 'Kawshik', 'Roy', 0),
(43, 'Nitai', 'Roy', 0),
(44, 'How', 'Are ', 0),
(45, 'Manik Roy ', 'Tagor', 0),
(46, 'Tagor Roy', 'Manik', 0),
(47, 'Antor  ', 'Roy', 0),
(48, 'Mampi ', 'Roy', 0),
(49, 'Kawshik', 'Roy', 0),
(50, 'Nitai', 'Roy', 0),
(51, 'How', 'Are ', 0),
(52, 'Manik Roy ', 'Tagor', 0),
(53, 'Tagor Roy', 'Manik', 0),
(54, 'Antor  ', 'Roy', 0),
(55, 'Mampi ', 'Roy', 0),
(56, 'Manik Roy ', 'Tagor', 0),
(57, 'Tagor Roy', 'Manik', 0),
(58, 'Antor  ', 'Roy', 0),
(59, 'Mampi ', 'Roy', 0),
(60, 'Kawshik', 'Roy', 0),
(61, 'Nitai', 'Roy', 0),
(62, 'How', 'Are ', 0),
(63, 'Manik Roy ', 'Tagor', 0),
(64, 'Tagor Roy', 'Manik', 0),
(65, 'Antor  ', 'Roy', 0),
(66, 'Mampi ', 'Roy', 0),
(67, 'Kawshik', 'Roy', 0),
(68, 'Nitai', 'Roy', 0),
(69, 'How', 'Are ', 0),
(70, 'Manik Roy ', 'Tagor', 0),
(71, 'Tagor Roy', 'Manik', 0),
(72, 'Antor  ', 'Roy', 0),
(73, 'Mampi ', 'Roy', 0),
(74, 'Kawshik', 'Roy', 0),
(75, 'Nitai', 'Roy', 0),
(76, 'How', 'Are ', 0),
(77, 'Manik Roy ', 'Tagor', 0),
(78, 'Tagor Roy', 'Manik', 0),
(79, 'Antor  ', 'Roy', 0),
(80, 'Mampi ', 'Roy', 0),
(81, 'Kawshik', 'Roy', 0),
(82, 'Nitai', 'Roy', 0),
(83, 'How', 'Are ', 0),
(84, 'Manik Roy ', 'Tagor', 0),
(85, 'Tagor Roy', 'Manik', 0),
(86, 'Antor  ', 'Roy', 0),
(87, 'Mampi ', 'Roy', 0),
(88, 'Kawshik', 'Roy', 0),
(89, 'Nitai', 'Roy', 0),
(90, 'How', 'Are ', 0),
(91, 'Manik Roy ', 'Tagor', 0),
(92, 'Tagor Roy', 'Manik', 0),
(93, 'Antor  ', 'Roy', 0),
(94, 'Mampi ', 'Roy', 0),
(95, 'Kawshik', 'Roy', 0),
(96, 'Nitai', 'Roy', 0),
(97, '25', '96', 0);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`Adminid`);

--
-- Indexes for table `category`
--
ALTER TABLE `category`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `deliveryhistory`
--
ALTER TABLE `deliveryhistory`
  ADD PRIMARY KEY (`hisid`);

--
-- Indexes for table `orderfromtable`
--
ALTER TABLE `orderfromtable`
  ADD PRIMARY KEY (`orderid`);

--
-- Indexes for table `payments`
--
ALTER TABLE `payments`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `paymentshistory`
--
ALTER TABLE `paymentshistory`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `product`
--
ALTER TABLE `product`
  ADD PRIMARY KEY (`proId`);

--
-- Indexes for table `subcategory`
--
ALTER TABLE `subcategory`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tables`
--
ALTER TABLE `tables`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `timer`
--
ALTER TABLE `timer`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `Adminid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `category`
--
ALTER TABLE `category`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;

--
-- AUTO_INCREMENT for table `deliveryhistory`
--
ALTER TABLE `deliveryhistory`
  MODIFY `hisid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=187;

--
-- AUTO_INCREMENT for table `orderfromtable`
--
ALTER TABLE `orderfromtable`
  MODIFY `orderid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=218;

--
-- AUTO_INCREMENT for table `payments`
--
ALTER TABLE `payments`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `paymentshistory`
--
ALTER TABLE `paymentshistory`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `product`
--
ALTER TABLE `product`
  MODIFY `proId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `subcategory`
--
ALTER TABLE `subcategory`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `tables`
--
ALTER TABLE `tables`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=30;

--
-- AUTO_INCREMENT for table `timer`
--
ALTER TABLE `timer`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=98;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
