<?php
include('inc/header.php');
error_reporting(0);
?>
<?php
include 'classes/Table.php';
$table = new Table();
?>
<?php
include 'lib/Session.php';
Session::checkUserSession();
$tableName = Session::get("tableName");
?>
<?php include 'inc/mainnav.php'; ?>
<div class="row">
	<div class="container-fluid">
		
		<?php include('inc/categoryinc.php');?>
		<div class="col-md-7" style="min-height: 480px;">
			<div class="panel panel-default">
				<div class="panel-heading text-center" style="font-size: 20px; font-weight: bolder;">Your Ordered Products</div>
				<div class="panel-body">
					<div class="table-responsive">
						<table class="table table-striped table-bordered table-hover" id="dataTables-example">
							<thead>
								<?php if (isset($orderDeny)) {
									echo $orderDeny;
								} ?>
								<tr style="width: 100%;">
									<th colspan="6" class="text-center">Ordered Product</th>
								</tr>
								<tr style="width: 100%;">
									<th class="text-center">SL</th>
									<th class="text-center">Product Name</th>
									<th class="text-center">Quantity</th>
									<th class="text-center">Price</th>
									<th class="text-center">Action</th>
								</tr>
							</thead>
							<tbody>
								
								<?php
								
									$getAllTables = $table->getAllTables();
									if($getAllTables){
										$i=0;
									while ($row = $getAllTables->fetch_assoc()) {
										$i++;
								?>
								<tr class="odd gradeX" style="width: 100%;">
									<td class="center"><?php echo $i; ?></td>
									<td class="center"><?php echo $row['tableName']; ?></td>
									<td class="text-center">
										
										<a href="?delid=<?php echo $row['orderid']; ?>" class="btn btn-danger btn-sm" >Clear</a>
									</td>
									
								</tr>
								<?php	} }?>
								<tr class="odd gradeX" style="width: 100%;">
									<td class="text-center" colspan="3" class="text-right">Total:</td>
									<td colspan="" rowspan="" headers="" class="text-center"><?php echo $sum; ?></td>
									
								</tr>
							</tbody>
						</table>
					</div>
				</div>
			</div>
		</div>
		<?php include('inc/orderpage.php');?>
		
	</div>
</div>
<?php include 'inc/footer.php'; ?>