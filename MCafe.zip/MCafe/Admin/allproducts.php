<?php include 'inc/adminheader.php';
?>
<?php
include '../classes/Category.php';
$cat = new Category();
?>
<?php include '../classes/Product.php';
$pro = new Product();
?>
<?php
include '../lib/Session.php';
Session::checkAdminSession();
$adminUser = Session::get("adminUser");
error_reporting(0);
?>
<?php
if(isset($_GET['delid'])){
$id = $_GET['delid'];
$delpro = $pro->delProductById($id);
}
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['submit'])) {
	$insertProduct = $pro->productInsert($_POST);
}
?>
<?php include 'inc/adminnav.php';?>
<div class="row">
	<div class="container-fluid">
		<?php include 'inc/leftsidebar.php';?>
		<div class="col-md-10" style="min-height: 480px;">
			<div class="panel panel-default">
				<div class="panel-heading text-center" style="font-size: 20px; font-weight: bolder;">All Products<a href="" class="btn btn-warning btn-sm pull-right" data-toggle="modal" data-target="#exampleModal" data-whatever="@mdo">Add</a></div>
				<div class="panel-body">
					<div class="table-responsive">
						<table class="table table-striped table-bordered table-hover table-condensed" id="dataTables-example">
							<thead>
								<?php if (isset($delpro)) {
								echo $delpro;
								}
								?>
								<?php 
					if (isset($insertProduct)) {
					echo $insertProduct;
					} ?>
								<tr style="width: 100%;">
									<th class="text-center">SL</th>
									<th class="text-center">Product Name</th>
									<th class="text-center">Category</th>
									<th class="text-center">Description</th>
									<th class="text-center">Price</th>
									<th class="text-center">Action</th>
								</tr>
							</thead>
							<tbody>
								<?php
								$getAllProducts = $pro->getAllProducts();
								if ($getAllProducts) {
								$i = 0;
								while ($row = $getAllProducts->fetch_assoc()) {
								$i++;
								?>
								<tr class="odd gradeX" style="width: 100%;">
									<td class="text-center"><?php echo $i; ?></td>
									<td class="center"><?php echo $row['ProName']; ?></td>
									<td class="text-center"><?php echo $row['proCat']; ?></td>
									<td class="text-center"><?php echo $row['Description']; ?></td>
									<td class="text-center"><?php echo $row['price']; ?></td>
									<td class="text-center" style="width: 15%">
										<a href="editproduct.php?editid=<?php echo $row['proId']; ?>"  class="btn btn-success btn-sm">Edit</a>
										<a href="?delid=<?php echo $row['proId']; ?>"  class="btn btn-danger btn-sm">Delete</a>
									</td>
								</tr>
								<?php	} } ?>
								<tr>
									<td colspan="4" rowspan="" headers="" class="text-right">Total: </td>
									<td colspan="" rowspan="" headers="" class="text-center"><?php echo $sum; ?></td>
								</tr>
							</tbody>
						</table>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
<?php include 'inc/adminfooter.php';?>
<!-- Modal -->
<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
	<div class="modal-dialog" role="document">
		<div class="modal-content">
			<div class="modal-header">
				<h3 class="modal-title" id="exampleModalLabel">Add Product<button type="button" class="close" data-dismiss="modal" aria-label="Close">
				<span aria-hidden="true">&times;</span></h3>
				</button>
			</div>
			
			
			<div class="modal-body">
			<?php 
					if (isset($insertProduct)) {
					echo $insertProduct;
					} ?>
					<form class="form-horizontal" action="" method="POST">
						<div class="form-group">
							<div class="col-sm-6">
								<label class="control-label" for="proname">Product Name:</label>
								<input type="text" class="form-control" id="proname" name="proname" placeholder="Enter Product Name">
							</div>
							<div class="col-sm-6">
								<label class="control-label" for="email">Product Category:</label>
								<select class="form-control" id="category" name="procat">
									<option>Select Category</option>
									<?php
									$cat = $cat->getAllCat();
									if ($cat) {
									while ($row = $cat->fetch_assoc()) {
									?>
									<option value="<?php echo $row['CatName']; ?>"><?php echo $row['CatName']; ?></option>
									<?php }} ?>
								</select>
							</div>
						</div>
						<div class="form-group">
							<div class="col-sm-6">
								<label class="control-label" for="proname">Product Description:</label>
								<textarea name="description" placeholder="Product Description" class="form-control"></textarea>
							</div>
							<div class="col-sm-6">
								<label class="control-label" for="email">Product Price:</label>
								<input type="number" class="form-control" id="price" name="proprice" placeholder="Enter Product Price">
							</div>
						</div>
						<div class="form-group">
							<div class="col-sm-offset-4 col-sm-8">
								<button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
					<button type="submit" name="submit" class="btn btn-primary">Submit</button>
							</div>
						</div>
					</form>

			</div>
		</div>
	</div>
</div>

	<!--End  Modal -->