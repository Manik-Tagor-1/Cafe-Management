<?php include 'inc/adminheader.php';
?>
<?php include '../classes/Tables.php';
$table = new Table();
?>
<?php
include '../lib/Session.php';
Session::checkAdminSession();
$adminUser = Session::get("adminUser");
error_reporting(0);
?>
<?php
if(isset($_GET['resetid'])){
$tableName = $_GET['resetid'];
$resettable = $table->allReset($tableName);
}
if(isset($_GET['delid'])){
$id = $_GET['delid'];
$deltable = $table->deltableById($id);
}
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['submit'])) {
	$tableInsert = $table->tableInsert($_POST);
}
?>
<?php include 'inc/adminnav.php';?>
<div class="row">
	<div class="container-fluid">
		<?php include('inc/leftsidebar.php');?>
		<div class="col-md-10" style="min-height: 480px;">
			<div class="panel panel-default">
				<div class="panel-heading text-center" style="font-size: 20px; font-weight: bolder;">All Tables<a href="" class="btn btn-warning btn-sm pull-right" data-toggle="modal" data-target="#exampleModal" data-whatever="@mdo">Add</a></div>
				<div class="panel-body">
					<?php if (isset($deltable)) {
								echo $deltable;
								}
					?>
					<?php if (isset($tableInsert)) {
					echo $tableInsert;
					}?>
					<div class="row">
						<!-- Nav_Tabs -->
						<div class="tabbable"> <!-- Only required for left/right tabs -->
						<ul class="nav nav-tabs">
							<li class="active"><a href="#tab1" data-toggle="tab">Set Timer</a></li>
							<li><a href="#tab2" data-toggle="tab">Table User Information</a></li>
						</ul>
						<div class="tab-content">
							<div class="tab-pane active" id="tab1">
								<div class="table-responsive">
									<table class="table table-striped table-bordered table-hover table-condensed" id="dataTables-example">
										<thead>
											
											<tr style="width: 100%;">
												<th class="text-center">SL</th>
												<th class="text-center">Table Name</th>
												<th class="text-center">Times Remaining</th>
												<th class="text-center">Action</th>
											</tr>
										</thead>
										<tbody>
											<?php
											$getAlltable = $table->getAlltable();
											if ($getAlltable) {
											$i = 0;
											while ($row = $getAlltable->fetch_assoc()) {
											$i++;
											?>
											<tr class="odd gradeX" style="width: 100%;">
												<td class="text-center"><?php echo $i; ?></td>
												<td class="text-center"><?php echo $row['tableName']; ?></td>
												<td class="text-center"> <p> Your time is setting up now.</p></td>
												<td  class="text-center" style="width: 20%;"> 	<a href="settimer.php?tab=<?php echo $row['tableName']; ?>"  class="btn btn-success btn-sm">Set Up Timing</a>	<a href="?resetid=<?php echo $row['tableName']; ?>"  class="btn btn-warning btn-sm">Clean It</a>
											</td>
										</tr>
										<?php }}?>
									</tbody>
								</table>
							</div>
						</div>
						<div class="tab-pane" id="tab2">
							<div class="table-responsive">
								<table class="table table-striped table-bordered table-hover table-condensed" id="dataTables-example">
									<thead>										
										<tr style="width: 100%;">
											<th class="text-center">SL</th>
											<th class="text-center">Table Name</th>
											<th class="text-center">Password</th>
											<th class="text-center">Action</th>
										</tr>
									</thead>
									<tbody>
										<?php
										$getAlltable = $table->getAlltable();
										if ($getAlltable) {
										$i = 0;
										while ($row = $getAlltable->fetch_assoc()) {
										$i++;
										?>
										<tr class="odd gradeX" style="width: 100%;">
											<td class="text-center"><?php echo $i; ?></td>
											<td class="text-center"><?php echo $row['tableName']; ?></td>
											<td class="text-center"><?php echo $row['Password']; ?></td>
											<td  class="text-center" style="width: 15%;"> 	<a href="edittable.php?editid=<?php echo $row['id']; ?>"  class="btn btn-success btn-sm">Edit</a>
											<a href="?delid=<?php echo $row['id']; ?>"  class="btn btn-danger btn-sm">Delete</a>
										</td>
									</tr>
									<?php }}?>
								</tbody>
							</table>
						</div>
					</div>
					
					
				</div>
			</div>
			
		</div>
		
	</div>
</div>
</div>
</div>
</div>
<?php include 'inc/adminfooter.php';?>
<!-- Modal -->
<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
<div class="modal-dialog" role="document">
<div class="modal-content">
<div class="modal-header">
	<h3 class="modal-title" id="exampleModalLabel">Add Table<button type="button" class="close" data-dismiss="modal" aria-label="Close">
	<span aria-hidden="true">&times;</span></h3>
	</button>
</div>
<div class="modal-body">
	<?php if (isset($tableInsert)) {
		echo $tableInsert;
	}?>
	<form class="form-horizontal" action="" method="POST">
		<div class="form-group">
			<div class="col-sm-6">
				<label class="control-label" for="proname">Table Name:</label>
				<input type="text" class="form-control" id="proname" name="tablename" placeholder="Enter Table Name">
			</div>
			
			<div class="col-sm-6">
				<label class="control-label" for="proname">Password:</label>
				<input type="password" name="tablepass" id="" placeholder="Enter Password" class="form-control">
			</div>
		</div>
		<div class="form-group">
			<div class="col-sm-offset-4 col-sm-8">
				<button type="submit" name="submit" class="btn btn-primary">Submit</button>
			</div>
		</div>
	</form>
</div>
</div>
</div>
</div>
<!--End  Modal -->