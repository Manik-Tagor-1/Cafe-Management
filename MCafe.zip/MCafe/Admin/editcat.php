<?php include 'inc/adminheader.php';?>
<?php
include '../lib/Session.php';
Session::checkAdminSession();
$adminUser = Session::get("adminUser");
?>
<?php
include '../classes/Category.php';
$cat = new Category();
include '../classes/Product.php';
$product = new Product();
if (isset($_GET['editid'])) {
	$editid = $_GET['editid'];
}
?>
<?php
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['update'])) {
	$catUpdate = $cat->catUpdate($_POST, $editid);
}
?>
<?php include 'inc/adminnav.php';?>
<div class="row">
	<div class="container-fluid">
		<?php include 'inc/leftsidebar.php';?>
		<div class="col-md-10" style="min-height: 480px;">
			<div class="panel panel-default">
				<div class="panel-heading text-center" style="font-size: 20px; font-weight: bolder;">Add Product</div>
				<div class="panel-body">
					<?php if (isset($catUpdate)) {
						echo $catUpdate;
					} ?>
					<?php
					$getCatById = $cat->getCatById($editid);
					if ($getCatById) {
					while ($value = $getCatById->fetch_assoc()) {
					?>
					<form class="form-horizontal" action="" method="POST">
						<div class="form-group">
							<div class="col-sm-6">
								<label class="control-label" for="proname">Category Name:</label>
								<input type="text" class="form-control" value="<?php echo $value['CatName']; ?>" id="proname" name="catname">
							</div>
						</div>
						<div class="form-group">
							<div class="col-sm-6">
								<label class="control-label" for="proname">Category Description:</label>
								<textarea name="description" placeholder="Product Description" class="form-control"><?php echo $value['description']; ?></textarea>
							</div>
						</div>
						<div class="form-group">
							<div class="col-sm-offset-4 col-sm-8">
								<input type="submit" name="update" class="btn btn-warning" value="Update">
							</div>
						</div>
					</form>
					<?php }}?>
				</div>
			</div>
		</div>
	</div>
</div>
<?php include 'inc/adminfooter.php';?>