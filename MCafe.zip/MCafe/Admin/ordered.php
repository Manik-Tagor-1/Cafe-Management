<?php include('inc/adminheader.php');
?>
<?php
include '../classes/Category.php';
$cat = new Category();
?>
<?php include '../classes/Product.php';
$pro = new Product();
?>
<?php include '../classes/Order.php';
$order = new Order();
?>
<?php
include '../lib/Session.php';
Session::checkAdminSession();
$adminUser = Session::get("adminUser");
error_reporting(0);
?>
<?php
if(isset($_GET['successid'])){
$successid = $_GET['successid'];
$orderAccept = $order->orderAccept($successid);
}
if(isset($_GET['pendingid'])){
$pendingid = $_GET['pendingid'];
$orderPending = $order->orderPending($pendingid);
}
if(isset($_GET['delid'])){
$delid = $_GET['delid'];
$orderDeny = $order->orderDeny($delid);
}
?>
<?php include 'inc/adminnav.php'; ?>
<div class="row">
	<div class="container-fluid">
		<?php include('inc/leftsidebar.php');?>
		<div class="col-md-10" style="min-height: 480px;">
			<div class="panel panel-default">
				<div class="panel-heading text-center" style="font-size: 20px; font-weight: bolder;">Ordered Product</div>
				<div class="panel-body">
					
					<?php if (isset($orderDeny)) {
						echo $orderDeny;
					}
					?>
					<div class="row">
						<!-- Nav_Tabs -->
						<div class="tabbable"> <!-- Only required for left/right tabs -->
						<ul class="nav nav-tabs">
							<li class="active"><a href="#tab1" data-toggle="tab">Ordered</a></li>
							<li><a href="#tab2" data-toggle="tab">Delivered</a></li>
							<li><a href="#tab3" data-toggle="tab">Pending</a></li>
							<li><a href="#tab4" data-toggle="tab">Denied</a></li>
						</ul>
						<div class="tab-content">
							<div class="tab-pane active" id="tab1">
								<div class="table-responsive">
									<table class="table table-striped table-bordered table-hover table-condensed" id="dataTables-example">
										<thead>
											
											<tr style="width: 100%;">
												<th class="text-center">SL</th>
												<th class="text-center">Table Name</th>
												<th class="text-center">Product Name</th>
												<th class="text-center">Quantity</th>
												<th class="text-center">Price</th>
												<th class="text-center">Action</th>
											</tr>
										</thead>
										<tbody>
											
											<?php
											
												$getAllOrder = $order->getAllOrder();
												if($getAllOrder){
													$i = 0;
													$sum = 0;
												while ($row = $getAllOrder->fetch_assoc()) {
													$i++;
											?>
											<tr class="odd gradeX" style="width: 100%;">
												<td class="text-center"><?php echo $i; ?></td>
												<td class="center"><?php echo $row['tableName']; ?></td>
												<td class="center"><?php echo $row['productName']; ?></td>
												<td class="text-center"><?php echo $row['Quantity']; ?></td>
												<td class="text-center"><?php echo $total= $row['ProPrice']; ?></td>
												<td class="center" style="width: 20%">
													<a href="?successid=<?php echo $row['orderid']; ?>"  class="btn btn-success btn-sm">Ok</a>
													<a href="?pendingid=<?php echo $row['orderid']; ?>" class="btn btn-warning btn-sm">Take Time</a>
													<a href="?delid=<?php echo $row['orderid']; ?>" class="btn btn-danger btn-sm" >Delete</a>
												</td>
												<?php $sum = $sum + $total; ?>
											</tr>
											<?php	} }?>
											<tr>
												<td colspan="4" rowspan="" headers="" class="text-right">Total: </td>
												<td colspan="" rowspan="" headers="" class="text-center"><?php echo $sum; ?></td>
											</tr>
										</tbody>
									</table>
								</div>
							</div>
							<div class="tab-pane" id="tab2">
								<div class="table-responsive">
									<table class="table table-striped table-bordered table-hover table-condensed" id="dataTables-example">
										<thead>
											
											<tr style="width: 100%;">
												<th class="text-center">SL</th>
												<th class="text-center">Table Name</th>
												<th class="text-center">Product Name</th>
												<th class="text-center">Quantity</th>
												<th class="text-center">Price</th>
												<th class="text-center">Action</th>
											</tr>
										</thead>
										<tbody>
											
											<?php
											
												$getAcptOdrAdmin = $order->getAcceptedOrderForAdmin();
												if($getAcptOdrAdmin){
													$i = 0;
													$sum = 0;
												while ($row = $getAcptOdrAdmin->fetch_assoc()) {
													$i++;
											?>
											<tr class="odd gradeX" style="width: 100%;">
												<td class="text-center"><?php echo $i; ?></td>
												<td class="center"><?php echo $row['tableName']; ?></td>
												<td class="center"><?php echo $row['productName']; ?></td>
												<td class="text-center"><?php echo $row['Quantity']; ?></td>
												<td class="text-center"><?php echo $total= $row['ProPrice']; ?></td>
												<td class="text-center" style="width: 10%">
													<a href="?delid=<?php echo $row['orderid']; ?>" class="btn btn-danger btn-sm" >Delete</a>
												</td>
												<?php $sum = $sum + $total; ?>
											</tr>
											<?php	} }?>
											<tr>
												<td colspan="4" rowspan="" headers="" class="text-right">Total: </td>
												<td colspan="" rowspan="" headers="" class="text-center"><?php echo $sum; ?></td>
											</tr>
										</tbody>
									</table>
								</div>
							</div>
							<div class="tab-pane" id="tab3">
								<div class="table-responsive">
									<table class="table table-striped table-bordered table-hover table-condensed" id="dataTables-example">
										<thead>
											
											<tr style="width: 100%;">
												<th class="text-center">SL</th>
												<th class="text-center">Table Name</th>
												<th class="text-center">Product Name</th>
												<th class="text-center">Quantity</th>
												<th class="text-center">Price</th>
												<th class="text-center">Action</th>
											</tr>
										</thead>
										<tbody>
											
											<?php
											
												$getPendingOrder = $order->getPendingOrder();
												if($getPendingOrder){
													$i = 0;
													$sum = 0;
												while ($row = $getPendingOrder->fetch_assoc()) {
													$i++;
											?>
											<tr class="odd gradeX" style="width: 100%;">
												<td class="text-center"><?php echo $i; ?></td>
												<td class="center"><?php echo $row['tableName']; ?></td>
												<td class="center"><?php echo $row['productName']; ?></td>
												<td class="text-center"><?php echo $row['Quantity']; ?></td>
												<td class="text-center"><?php echo $total= $row['ProPrice']; ?></td>
												<td class="text-center" style="width: 15%">
													<a href="?successid=<?php echo $row['orderid']; ?>"  class="btn btn-success btn-sm">Ok</a>
													<a href="?delid=<?php echo $row['orderid']; ?>" class="btn btn-danger btn-sm" >Delete</a>
												</td>
												<?php $sum = $sum + $total; ?>
											</tr>
											<?php	} }?>
											<tr>
												<td colspan="4" rowspan="" headers="" class="text-right">Total: </td>
												<td colspan="" rowspan="" headers="" class="text-center"><?php echo $sum; ?></td>
											</tr>
										</tbody>
									</table>
								</div>
							</div>
							<div class="tab-pane" id="tab4">
								<div class="table-responsive">
									<table class="table table-striped table-bordered table-hover table-condensed" id="dataTables-example">
										<thead>
											
											<tr style="width: 100%;">
												<th class="text-center">SL</th>
												<th class="text-center">Table Name</th>
												<th class="text-center">Product Name</th>
												<th class="text-center">Quantity</th>
												<th class="text-center">Price</th>
												<th class="text-center">Action</th>
											</tr>
										</thead>
										<tbody>
											
											<?php
											
												$getDeniedOrder = $order->getDeniedOrder();
												if($getDeniedOrder){
													$i = 0;
													$sum = 0;
												while ($row = $getDeniedOrder->fetch_assoc()) {
													$i++;
											?>
											<tr class="odd gradeX" style="width: 100%;">
												<td class="text-center"><?php echo $i; ?></td>
												<td class="center"><?php echo $row['tableName']; ?></td>
												<td class="center"><?php echo $row['productName']; ?></td>
												<td class="text-center"><?php echo $row['Quantity']; ?></td>
												<td class="text-center"><?php echo $total= $row['ProPrice']; ?></td>
												<td class="text-center" style="width: 15%">
													<a href="?successid=<?php echo $row['orderid']; ?>"  class="btn btn-success btn-sm">Ok</a>
													<a href="?delid=<?php echo $row['orderid']; ?>" class="btn btn-danger btn-sm" >Delete</a>
												</td>
												<?php $sum = $sum + $total; ?>
											</tr>
											<?php	} }?>
											<tr>
												<td colspan="4" rowspan="" headers="" class="text-right">Total: </td>
												<td colspan="" rowspan="" headers="" class="text-center"><?php echo $sum; ?></td>
											</tr>
										</tbody>
									</table>
								</div>
							</div>
						</div>
					</div>
					
				</div>
				
			</div>
		</div>
	</div>
</div>
</div>
<?php include 'inc/adminfooter.php'; ?>