<?php include('inc/header.php');?>
<?php
include 'classes/Category.php';
$cat = new Category();
?>
<?php include 'classes/Product.php';
$pro = new Product();
?>
<?php include 'classes/Order.php';
$order = new Order();
?>
<?php
include 'lib/Session.php';
Session::checkUserSession();
$tableName = Session::get("tableName");
?>
<?php
if(isset($_GET['updateid'])){
$orderid = $_GET['updateid'];
}
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
$updateCart = $order->updateCart($_POST,$orderid);
}
?>
<?php include 'inc/mainnav.php'; ?>
<div class="row">
	<div class="container-fluid">
		<?php include('inc/categoryinc.php');?>
		<div class="col-md-7" style="min-height: 480px;">
			<?php
			if (isset($updateCart)) {
			echo $updateCart;
			}
				$order = $order->getOrderedProduct($orderid);
				if($order){
				while ($row = $order->fetch_assoc()) {
			?>
			<p>Product Name : <?php echo $row['productName']; ?></p>
			<p>Product Price : <?php echo $row['ProPrice']; ?> Taka</p>
			
			
			<form action="" method="post">
				<input type="number" class="col-sm-2 form-control" name="quantity" value="1"/>
				<input type="submit" class="btn btn-info" name="submit" value="Update Quantity"/>
			</form>

			<?php } } ?>
		</div>
		<div class="col-md-3">
			
		</div>
	</div>
</div>
<?php include 'inc/footer.php'; ?>