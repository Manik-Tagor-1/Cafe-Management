<?php include 'inc/adminheader.php';
?>
<?php
include '../classes/Category.php';
$cat = new Category();
?>
<?php
include '../lib/Session.php';
Session::checkAdminSession();
$adminUser = Session::get("adminUser");
?>
<?php
if(isset($_GET['delid'])){
$id = $_GET['delid'];
$delsubcatById = $cat->delsubcatById($id);
}
?>
<?php
			if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['add'])) {
				$subCatInsert = $cat->subCatInsert($_POST);
			}
?>
<?php include 'inc/adminnav.php';?>
<div class="row">
	<div class="container-fluid">
		<?php include 'inc/leftsidebar.php';?>
		<div class="col-md-10" style="min-height: 480px;">
			<div class="panel panel-default">
				<div class="panel-heading text-center" style="font-size: 20px; font-weight: bolder;">Sub Category<a href="" class="btn btn-warning btn-sm pull-right" data-toggle="modal" data-target="#exampleModal" data-whatever="@mdo">Add</a></div>
				<div class="panel-body">
					<?php if (isset($subCatInsert)) {
								echo $subCatInsert;
								}
					?>
					<?php if (isset($delsubcatById)) {
								echo $delsubcatById;
								}
					?>
					<div class="table-responsive">
						<table class="table table-striped table-bordered table-hover table-condensed" id="dataTables-example">
							<thead>
								
								<tr style="width: 100%;">
									<th class="text-center">SL</th>
									<th class="text-center">Parent Category</th>
									<th class="text-center">Sub Category</th>
									<th class="text-center">Action</th>
								</tr>
							</thead>
							<tbody>
								<?php
								$getAllSubCat = $cat->getAllSubCat();
								if ($getAllSubCat) {
								$i = 0;
								while ($row = $getAllSubCat->fetch_assoc()) {
								$i++;
								?>
								<tr class="odd gradeX" style="width: 100%;">
									<td class="text-center"><?php echo $i; ?></td>
									<td class="text-center"><?php echo $row['parentcat']; ?></td>
									<td class="text-center"><?php echo $row['sub_category']; ?></td>
									<td  class="text-center" style="width: 15%;"> 	<a href="editsubcat.php?editid=<?php echo $row['id']; ?>"  class="btn btn-success btn-sm">Edit</a>
									<a href="?delid=<?php echo $row['id']; ?>"  class="btn btn-danger btn-sm">Delete</a>
								</td>
							</tr>
							<?php }}?>
						</tbody>
					</table>
				</div>
			</div>
		</div>
	</div>
</div>
<?php include 'inc/adminfooter.php';?>
<!-- Modal -->
<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
	<div class="modal-dialog" role="document">
		<div class="modal-content">
			<div class="modal-header">
				<h3 class="modal-title" id="exampleModalLabel">Sub Category<button type="button" class="close" data-dismiss="modal" aria-label="Close">
				<span aria-hidden="true">&times;</span></h3>
				
				</button>
			</div>
			
			
			<div class="modal-body">
				<?php if (isset($subCatInsert)) {
					echo $subCatInsert;
				} ?>
				<form action="" method="POST">
					<div class="form-group">
						<label for="recipient-name" class="col-form-label">Select Category:</label>
						<select name="parentcat" id="" class="form-control">
							<?php
								$getAllSubCat = $cat->getAllCat();
								if ($getAllSubCat) {
								$i = 0;
								while ($row = $getAllSubCat->fetch_assoc()) {
								$i++;
							?>
							<option value="<?php echo $row['CatName']; ?>" > <?php echo $row['CatName']; ?></option>
							<?php } } ?>
						</select>
					</div>
					<div class="form-group">
						<label for="message-text" class="col-form-label">Sub Category:</label>
						<input type="text" class="form-control" name="sub_category" placeholder="Enter Sub Category">
					</div>
					
				</div>
				<div class="modal-footer">
					<button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
					<button type="submit" name="add" class="btn btn-primary">Add</button>
				</div>
			</form>
		</div>
	</div>
</div>
<!--End  Modal -->