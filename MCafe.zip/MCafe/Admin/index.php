<?php include 'inc/adminheader.php';?>
<?php
include '../lib/Session.php';
Session::checkAdminSession();
$adminUser = Session::get("adminUser");
?>
<?php include 'inc/adminnav.php';?>
<div class="row">
	<div class="container-fluid">
		<?php include 'inc/leftsidebar.php';?>
		<div class="col-md-10" style="min-height: 480px;">
			<div class="row Ctrl">
				<p class="text-center slogOne">Cafe Management System</p>
				<p class="text-center slogTwo">By</p>
				<p class="text-center slogThree">Team Innovator</p>
			</div>
			<!-- Nav_Tabs -->
			<!-- <div class="tabbable"> 
			<ul class="nav nav-tabs">
				<li class="active"><a href="#tab1" data-toggle="tab">Section 1</a></li>
				<li><a href="#tab2" data-toggle="tab">Section 2</a></li>
			</ul>
			<div class="tab-content">
				<div class="tab-pane active" id="tab1">
					<p>I'm in Section 1. Lorem ipsum dolor, sit amet consectetur adipisicing elit. Minus repellendus nesciunt ipsa architecto, et. Dolore sed placeat, voluptates, dolorum sint aliquam accusamus iure inventore saepe nesciunt, exercitationem qui temporibus odio!
					</p>
				</div>
				<div class="tab-pane" id="tab2">
					<p>Howdy, I'm in Section 2.</p>
				</div>
			</div>
		</div> -->
		<!-- Nav_Tabs -->
	</div>
</div>
</div>
<?php include 'inc/adminfooter.php';?>
<style type="text/css" media="screen">
.box{
height: 130px;
border-radius: 5px;
margin: 0 auto;
}
.bx-span{
font-size: 35px;
font-family: monospace;
font-weight: bolder;
text-align: center;
color: aliceblue;
}
.slogOne{
	font-size: 60px;
font-family: cursive;
font-weight: bold;
font-style: oblique;
}
.slogTwo{
	font-size: 25px;
font-family: cursive;
font-weight: bold;
font-style: oblique;
}
.slogThree{
	font-size: 35px;
font-family: cursive;
font-weight: bold;
font-style: oblique;
}
.Ctrl{
	margin: 15% 0px 0px 0px;
}
</style>