
<section class="menu-section">
  <div class="container">
    <div class="row ">
      <div class="col-md-12">
        <?php
        $adminUser = Session::get("adminUser");
        if($adminUser){
        ?>
        <div class="navbar-collapse collapse ">
          <ul id="menu-top" class="nav navbar-nav navbar-left">
            <li>
              <a href="index.php" class="menu-top-active cusTom">
                <?php  echo $adminUser= Session::get("adminUser") ?>
              </a>
            </li>
          </ul>
          <ul id="menu-top" class="nav navbar-nav navbar-right">
            <!-- <li>
              <a href="userprofile.php"> Profile <i class="fa fa-angle-down"></i></a>
              <ul class="dropdown-menu" role="menu" aria-labelledby="ddlmenuItem">
                <li role="presentation"><a role="menuitem" tabindex="-1" href="userprofile.php">My Profile</a></li>
              </ul>
            </li> -->
            <!-- <li><a href="">Order</a></li> -->
          
            <li><a href="?lg=logout">Log Out</a></li>
            <?php }else{ ?><!-- 
            <li><a href="login.php">Login</a></li> -->
            <?php } ?>
          </ul>
        </div>
      </div>
    </div>
  </div>
</section>
<?php
if(isset($_GET['lg']) && $_GET['lg']=="logout"){
Session::destroy();
session_unset();
}
?>
<style>
  .cusTom{
    border: 2px solid #a95656;
    border-radius: 5px;
  }
</style>