<!-- Category Start -->
<div class="col-md-2" style="background: #ddd; min-height: 480px;">
	<div class="table-responsive">
		<table class="table table-striped table-bordered table-hover" id="dataTables-example">
			<thead>
				<tr>
					<th class="text-center"></th>
				</tr>
			</thead>
			<tbody>
				<tr class="odd gradeX">
					<td class="center customcat"><a href="ordered.php" title="">Ordered</a></td>
				</tr>
				<tr class="odd gradeX">
					<td class="center customcat"><a href="allproducts.php" title="">All Product</a></td>
				</tr><!-- 
				<tr class="odd gradeX">
					<td class="center customcat"><a href="addproduct.php" title="">Add Product</a></td>
				</tr> -->
				<tr class="odd gradeX">
					<td class="center customcat"><a href="alltables.php" title="">All Table</a></td>
				</tr><!-- 
				<tr class="odd gradeX">
					<td class="center customcat"><a href="addtable.php" title="">Add Table</a></td>
				</tr> -->
				<tr class="odd gradeX">
					<td class="center customcat"><a href="allcategory.php" title="">All Category</a></td>
				</tr>
				<tr class="odd gradeX">
					<td class="center customcat"><a href="subcategory.php" title="">Sub Category</a></td>
				</tr>
			</tbody>
		</table>
	</div>
</div>
<!-- Caregory End -->

<style>
	
	.customcat a{
text-decoration: none;
color: #000;
font-size: 15px;
font-weight: bold;
font-family: monospace;
}

</style>