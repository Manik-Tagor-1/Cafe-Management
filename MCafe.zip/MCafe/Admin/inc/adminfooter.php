<section class="footer-section">
	<div class="container">
		<div class="row">
			<div class="col-md-12 text-center">
				Copyright &copy; <?php echo date('Y'); ?> | All Right Reserved - Team Innovator |<a href="" target=""  > Developed by : Manik Chandro Roy & RAKIBUDDIN & Alsen Nathan Roy</a>
			</div>
		</div>
	</div>
</section>
<!-- FOOTER SECTION END-->
<script src="assets/js/jquery-1.10.2.js"></script>
<!-- BOOTSTRAP SCRIPTS  -->
<script src="assets/js/bootstrap.js"></script>
<!-- CUSTOM SCRIPTS  -->
<script src="assets/js/custom.js"></script>
</script>
</body>
</html>