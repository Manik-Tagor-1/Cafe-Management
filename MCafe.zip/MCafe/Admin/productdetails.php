<?php include('inc/header.php');?>
<?php
include 'classes/Category.php';
$cat = new Category();
?>
<?php include 'classes/Product.php';
$pro = new Product();
?>
<?php include 'classes/Order.php';
$order = new Order();
?>
<?php
include 'lib/Session.php';
Session::checkUserSession();
$tableName = Session::get("tableName");
error_reporting(0);
?>
<?php
if(isset($_GET['orderid'])){
$orderid = $_GET['orderid'];
}else{
	 header("Location: index.php");
}
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
$addCart = $order->addToCart($_POST);
}
?>
<?php include 'inc/mainnav.php'; ?>
<div class="row">
	<div class="container-fluid">
		<?php include('inc/categoryinc.php');?>
		<div class="col-md-7" style="min-height: 480px;">
			<?php
			if (isset($addCart)) {
			echo $addCart;
			}
				$pro = $pro->getSingleProduct($orderid);
				if($pro){
				while ($row = $pro->fetch_assoc()) {
			?>
			<?php echo $row['ProName']; ?>
			
			<form action="" method="post">
				<input type="hidden" class="col-md-2 form-control" name="ProductName" value="<?php echo $row['ProName']; ?>"/>
				<input type="hidden" class="" name="TableName" value="<?php echo $tableName; ?>"/>
				<input type="text" class="" name="ProductPrice" value="<?php echo $row['Price']; ?>"/>
				<input type="number" class="buyfield" name="quantity" value="1"/>
				<input type="submit" class="btn btn-info" name="submit" value="Cart Product"/>
			</form>
			<?php } } ?>
		</div>
		<?php include('inc/orderpage.php');?>
		
	</div>
</div>
<?php include 'inc/footer.php'; ?>