<?php include 'inc/adminheader.php';
?>
<?php include '../classes/Tables.php';
$table = new Table();
?>
<?php
include '../lib/Session.php';
Session::checkAdminSession();
$adminUser = Session::get("adminUser");
error_reporting(0);
?>
<?php
if(isset($_GET['tab'])){
$tableName = $_GET['tab'];
}
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['settimer'])) {
	$timer = $_POST['timer'];
	$timerInsert = $table->setAlltableTimer($tableName,$timer);
}
?>
<?php include 'inc/adminnav.php';?>
<div class="row">
	<div class="container-fluid">
		<?php include('inc/leftsidebar.php');?>
		<div class="col-md-10" style="min-height: 480px;">
			<div class="panel panel-default">
				<div class="panel-heading text-center" style="font-size: 20px; font-weight: bolder;">Set <?php echo $tableName ; ?> Timer</div>
				<div class="panel-body">
					
					<!--LOGIN PANEL START-->
					<div class="row">
						<div class="col-md-6 col-sm-6 col-xs-12 col-md-offset-3" >
							<div class="panel panel-info">
								<div class="panel-heading">
									Set your Delay Time
								</div>
								<div class="panel-body">
									
									<?php if (isset($timerInsert)) {
										echo $timerInsert;
									} ?>
									<form role="form" method="post">
										
										<div class="form-group">
											<label>Present Time</label>
											<?php date_default_timezone_set("Asia/Dhaka"); ?>
											<input type="datetime-local" class="form-control" name="" value="<?php echo date("Y-m-d\TH:i:s",time()); ?>" disabled/>
											<label>Set Timing</label>
											<input type="datetime-local" class="form-control" name="timer" value="<?php echo date("Y-m-d\TH:i:s",time()); ?>"/>
										</div>
										<button type="submit" name="settimer" class="btn btn-info">Set </button>
									</form>
								</div>
							</div>
						</div>
					</div>
					<!---LOGIN PABNEL END-->
					
				</div>
			</div>
		</div>
	</div>
</div>
<?php include 'inc/adminfooter.php';?>