<?php include 'inc/adminheader.php';?>
<?php
include '../lib/Session.php';
Session::checkAdminSession();
$adminUser = Session::get("adminUser");
?>
<?php
include '../classes/Tables.php';
$table = new Table();
include '../classes/Product.php';
$product = new Product();
if (isset($_GET['editid'])) {
	$editid = $_GET['editid'];
}
?>
<?php 
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['update'])) {
	$tableUpdate = $table->tableUpdate($_POST,$editid);
}
?>
<?php include 'inc/adminnav.php';?>
<div class="row">
	<div class="container-fluid">
		<?php include 'inc/leftsidebar.php';?>
		<div class="col-md-10" style="min-height: 480px;">
			<div class="panel panel-default">
				<div class="panel-heading text-center" style="font-size: 20px; font-weight: bolder;">Edit Table</div>
				<div class="panel-body">
					<?php if (isset($tableUpdate)) {
						echo $tableUpdate;
					} ?>
					<?php
					$gettableById = $table->gettableById($editid);
					if ($gettableById) {
					while ($value = $gettableById->fetch_assoc()) {
					?>
					<form class="form-horizontal" action="" method="POST">
						<div class="form-group">
							<div class="col-sm-6">
								<label class="control-label" for="proname">Table Name:</label>
								<input type="text" class="form-control" value="<?php echo $value['tableName']; ?>" id="proname" name="tablename" disabled>
							</div>
						</div>
						<div class="form-group">
							<div class="col-sm-6">
								<label class="control-label" for="proname">Password:</label>
								<input type="text" class="form-control" value="<?php echo $value['Password']; ?>" id="proname" name="tablepass">
							</div>
						</div>
						<div class="form-group">
							<div class="col-sm-offset-4 col-sm-8">
								<button type="submit" name="update" class="btn btn-warning">Update</button>
							</div>
						</div>
					</form>
					<?php }}?>
				</div>
			</div>
		</div>
	</div>
</div>
<?php include 'inc/adminfooter.php';?>