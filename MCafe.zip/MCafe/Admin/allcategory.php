<?php include 'inc/adminheader.php';
?>
<?php
include '../classes/Category.php';
$cat = new Category();
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['submit'])) {
	$catInsert = $cat->catInsert($_POST);
}
?>

<?php
if(isset($_GET['delid'])){
$id = $_GET['delid'];
$delCatById = $cat->delCatById($id);
}
?>
<?php
include '../lib/Session.php';
Session::checkAdminSession();
$adminUser = Session::get("adminUser");
?>
<?php include 'inc/adminnav.php';?>
<div class="row">
	<div class="container-fluid">
		<?php include 'inc/leftsidebar.php';?>
		<div class="col-md-10" style="min-height: 480px;">
			<div class="panel panel-default">
				<div class="panel-heading text-center" style="font-size: 20px; font-weight: bolder;">All Category<a href="" class="btn btn-warning btn-sm pull-right" data-toggle="modal" data-target="#exampleModal" data-whatever="@mdo">Add</a></div>
				<div class="panel-body">
					<?php if (isset($delCatById)) {
								echo $delCatById;
								}
								?>
					<?php if (isset($catInsert)) {
								echo $catInsert;
								}
								?>
					<div class="table-responsive">
						<table class="table table-striped table-bordered table-hover table-condensed" id="dataTables-example">
							<thead>
								
								<tr style="width: 100%;">
									<th class="text-center">SL</th>
									<th class="text-center">Category Name</th>
									<th class="text-center">Description</th>
									<th class="text-center">Action</th>
								</tr>
							</thead>
							<tbody>
								<?php
								$getAllCat = $cat->getAllCat();
								if ($getAllCat) {
								$i = 0;
								while ($row = $getAllCat->fetch_assoc()) {
								$i++;
								?>
								<tr class="odd gradeX" style="width: 100%;">
									<td class="text-center"><?php echo $i; ?></td>
									<td class="text-center"><?php echo $row['CatName']; ?></td>
									<td class="text-center"><?php echo $row['description']; ?></td>
									<td  class="text-center" style="width: 15%;"> 	<a href="editcat.php?editid=<?php echo $row['id']; ?>"  class="btn btn-success btn-sm">Edit</a>
									<a href="?delid=<?php echo $row['id']; ?>"  class="btn btn-danger btn-sm">Delete</a>
								</td>
							</tr>
							<?php }}?>
						</tbody>
					</table>
				</div>
			</div>
		</div>
	</div>
</div>
<?php include 'inc/adminfooter.php';?>

<!-- Modal -->
<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
	<div class="modal-dialog" role="document">
		<div class="modal-content">
			<div class="modal-header">
				<h3 class="modal-title" id="exampleModalLabel">Add Category<button type="button" class="close" data-dismiss="modal" aria-label="Close">
				<span aria-hidden="true">&times;</span></h3>
				</button>
			</div>
			
			
			<div class="modal-body">
				<?php if (isset($catInsert)) {
					echo $catInsert;
				} ?>
				<form action="" method="POST">
					
					<div class="form-group">
						<label for="message-text" class="col-form-label">Category:</label>
						<input type="text" class="form-control" name="catname" placeholder="Enter Category">
					</div>
					
					<div class="form-group">
						<label for="message-text" class="col-form-label">Description:</label>
						<textarea name="description" id="" cols="30" rows="5" class="form-control" placeholder="Type about this category."></textarea>
					</div>
					
				</div>
				<div class="modal-footer">
					<button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
					<button type="submit" name="submit" class="btn btn-primary">Add</button>
				</div>
			</form>
		</div>
	</div>
</div>
<!--End  Modal -->