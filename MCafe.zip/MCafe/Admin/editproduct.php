<?php include 'inc/adminheader.php';?>
<?php
include '../lib/Session.php';
Session::checkAdminSession();
$adminUser = Session::get("adminUser");
?>
<?php
include '../classes/Category.php';
$cat = new Category();
include '../classes/Product.php';
$product = new Product();
if (isset($_GET['editid'])) {
	$editid = $_GET['editid'];
}
?>
<?php
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['update'])) {
	$productUpdate = $product->productUpdate($_POST, $editid);
}
?>
<?php include 'inc/adminnav.php';?>
<div class="row">
	<div class="container-fluid">
		<?php include 'inc/leftsidebar.php';?>
		<div class="col-md-10" style="min-height: 480px;">
			<div class="panel panel-default">
				<div class="panel-heading text-center" style="font-size: 20px; font-weight: bolder;">Add Product</div>
				<div class="panel-body">
					<?php if (isset($productUpdate)) {
						echo $productUpdate;
					} ?>
					<?php
					$getProd = $product->getProById($editid);
					if ($getProd) {
					while ($value = $getProd->fetch_assoc()) {
					?>
					<form class="form-horizontal" action="" method="POST">
						<div class="form-group">
							<div class="col-sm-6">
								<label class="control-label" for="proname">Product Name:</label>
								<input type="text" class="form-control" value="<?php echo $value['ProName']; ?>" id="proname" name="proname">
							</div>
							<div class="col-sm-6">
								<label class="control-label" for="email">Product Category:</label>
								<select id="select" name="procat" class="form-control">
									<option>Select Category</option>
									<?php
									$gatCat = $cat->getAllCat();
									if ($gatCat) {
									while ($result = $gatCat->fetch_assoc()) {
									?>
									<option
										<?php
										if ($value['proCat'] == $result['CatName']) {?>
										selected = "selected"
										<?php
										}
									?> value="<?php echo $result['CatName']; ?>" ><?php echo $result['CatName']; ?></option>
									<?php }}?>
								</select>
							</div>
						</div>
						<div class="form-group">
							<div class="col-sm-6">
								<label class="control-label" for="proname">Product Description:</label>
								<textarea name="description" placeholder="Product Description" class="form-control"><?php echo $value['Description']; ?></textarea>
							</div>
							<div class="col-sm-6">
								<label class="control-label" for="email">Product Price:</label>
								<input type="number" class="form-control" id="price" name="proprice" placeholder="Enter Product Price" value="<?php echo $value['price']; ?>">
							</div>
						</div>
						<div class="form-group">
							<div class="col-sm-offset-4 col-sm-8">
								<button type="submit" name="update" class="btn btn-warning">Update</button>
							</div>
						</div>
					</form>
					<?php }}?>
				</div>
			</div>
		</div>
	</div>
</div>
<?php include 'inc/adminfooter.php';?>