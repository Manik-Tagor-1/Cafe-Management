<?php include('inc/header.php');?>
<?php
include 'classes/Category.php';
$cat = new Category();
?>
<?php include 'classes/Product.php';
$pro = new Product();
?>
<?php include 'classes/Order.php';
$order = new Order();
?>
<?php
include 'lib/Session.php';
Session::checkUserSession();
$tableName = Session::get("tableName");
?>
<?php  include 'inc/mainnav.php'; ?>
<div class="row">
	<div class="container-fluid">
	
		<?php include('inc/categoryinc.php');?>
		<?php include('inc/productpage.php');?>
		<?php include('inc/orderpage.php');?>
		
	</div>
</div>
<?php include 'inc/footer.php'; ?>