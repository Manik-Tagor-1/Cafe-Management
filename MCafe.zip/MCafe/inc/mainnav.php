<section class="menu-section">
  <div class="container">
    <div class="row ">
      <div class="col-md-12">
        <?php
        $UserLogin = Session::get("userlogin");
        if ($UserLogin) {
        ?>
        <div class="navbar-collapse collapse ">
          <ul id="menu-top" class="nav navbar-nav navbar-left">
            <li>
              <a href="index.php" class="menu-top-active cusTom">
                <?php echo $tableName = Session::get("tableName") ?>
              </a>
            </li>
          </ul>
          <ul id="menu-top" class="nav navbar-nav navbar-right">
           
            <li>
              <a href="notifications.php"><i class="glyphicon glyphicon-envelope" ></i></a>
            </li>
            <?php
            $getOrder = $order->getOrder($tableName);
            if ($getOrder > '0') { ?>
            <li><a href="cartproduct.php">Cart</a></li>
            <?php } ?>
            <?php
            
            $getAcceptedOrder = $order->getAcceptedOrder($tableName);
            if($getAcceptedOrder>'0'){
            ?>
            <li><a href="acceptorder.php">Delivered</a></li>
            <?php } ?>
            <li><a href="?lg=logout" class="btn btn-danger btn-sm">Log Out</a></li>
            <?php } ?>
          </ul>
        </div>
      </div>
    </div>
  </div>
</section>






<?php
if (isset($_GET['lg']) && $_GET['lg'] == "logout") {
Session::destroy();
session_unset();
}
?>
<style>
.cusTom{
border: 2px solid #a95656;
border-radius: 5px;
}
</style>



