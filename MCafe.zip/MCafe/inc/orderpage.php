<?php
/*if(isset($_GET['delid'])){
$delid = $_GET['delid'];
$DelCart = $order->orderDeny($delid);
}*/
?>

<div class="col-md-3" style="background: #ddd; min-height: 480px;">
	<div class="table-responsive">
		<table class="table table-striped table-bordered table-hover" id="dataTables-example">
		
			<thead>
			<tr>
				<th colspan="4" class="text-center">Cart Product</th>
			</tr>
				<tr>
					<th class="text-center">SL</th>
					<th class="text-center">Name</th>
					<th class="text-center">Qty</th>
					<th class="text-center">Price</th>
				</tr>
			</thead>
			<tbody>
				<?php
				$order = $order->getOrder($tableName);
				if($order){
					$i = 0;
					$sum = 0;
					$qty = 0;
				while ($row = $order->fetch_assoc()) {
					$i++;
				?>
				
				<tr class="odd gradeX">
					<td class="center"><?php echo $i; ?></td>
					<td class="center"><?php echo $row['productName']; ?></td>
					<td class="center"><?php echo $qty= $row['Quantity']; ?></td>
					<td class="center"><?php echo $total = $row['ProPrice']; ?></td>
					
					
					<?php $sum = $sum + $total; ?>
				</tr>
				<?php  } ?>
				<tr>
					<td colspan="3">Total: </td>
					<td class="center">
						
					<?php echo $sum; ?>

					</td>
				</tr>
				<?php }  ?>
			</tbody>
		</table>
	</div>
</div>