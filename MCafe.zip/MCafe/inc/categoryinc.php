<!-- Category Start -->
<div class="col-md-2" style="background: #ddd; min-height: 480px;">
	<div class="table-responsive">
		<table class="table table-striped table-bordered table-hover" id="dataTables-example">
			<thead>
				<tr>
					<th class="text-center">All Category</th>
				</tr>
			</thead>
			<tbody>
				<?php
				$cat = $cat->getAllCat();
				if($cat){
					$i=0;
				while ($row = $cat->fetch_assoc()) {
					$i++;
				?>
				
				<tr class="odd gradeX activealert">
					<td class="center customcat"><a href="index.php?catName=<?php echo $row['CatName']; ?>" title=""><?php  echo $catname = $row['CatName'];?></a></td>
					
				</tr>
				
				<?php } } ?>
			</tbody>
		</table>
	</div>
</div>
<!-- Caregory End -->
<style>
	
	.customcat a{
text-decoration: none;
color: #000;
font-size: 15px;
font-weight: bold;
font-family: monospace;
}

</style>