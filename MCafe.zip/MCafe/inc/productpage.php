<?php
if (isset($_GET['catName'])) {
	$catName = $_GET['catName'];
	$sub = $pro->getAllSubcatByCat($catName);
?>
<div class="col-md-7" style="min-height: 480px;">
	<div class="row">
		<div class="section">
			<?php
			
			if($sub) {
			while ($value = $sub->fetch_assoc()) {
			?>
			<p class="subcat" style=""><a href=""><?php echo $value['sub_category']; ?></a></p>
			<?php } } ?>
		</div>
	</div>
	<div class="row">
		
		<?php
		$pro = $pro->getAllProductByCat($catName);
		if ($pro) {
		while ($row = $pro->fetch_assoc()) {
		?>
		<div class="col-sm-3">
			<div class="box" style="background-color: #902e10;">
				<p class="bx-span"><?php echo $productName = $row['ProName']; ?></p>
				<p class="bx-span">Rs: <?php echo $row['price']; ?>/-</p>
				<a href="productdetails.php?orderid=<?php echo $row['proId']; ?>" title="" class="btn btn-warning btn-sm" name="details" style="margin: 10px 50px;">Details</a>
			</div>
		</div>
		<?php }}?>
	</div>
</div>
<?php } else {?>
<div class="col-md-7" style="min-height: 480px;">
	<div class="row Ctrl">
		<p class="text-center slogOne">Cafe Management System</p>
		<p class="text-center slogTwo">By</p>
		<p class="text-center slogThree">Team Innovator</p>
	</div>
	<div class="row">
		
		<script src="assets/js/jquery-3.3.1.min.js"></script>
		<script src="syotimer/jquery.syotimer.js"></script>
		<link rel="stylesheet" href="syotimer/default.css">
		<?php
		$selecttime = $pro->selecttime($tableName);
		if($selecttime){
		while ($row = $selecttime->fetch_assoc()) {
		// $countdown = "2022-06-07 16:00:00";
		$countdown = $row['datetimenow'];
		} }
		?>
		<div class="footer fixed-bottom">
			<?php if (isset($countdown)) {
				echo "Your Product will be delivered within ".$countdown." times.";
			}else{
				echo "Please wait for delivered.";
			} ?>
		</div>
		<div id="simple_timer"></div>
		<input type="hidden" id="timer_value" value="<?php  echo $countdown; ?>">
		<script type="text/javascript">
		$(function () {
		var timer_value = document.getElementById("timer_value").value;
		var date = new Date(timer_value);
		$('#simple_timer').syotimer({
		year: date.getFullYear(),
		month: date.getMonth() + 1,
		day: date.getDate(),
		hour: date.getHours(),
		minute: date.getMinutes(),
		seconds: date.getSeconds()
		});
		});
		</script>
	</div>
</div>
<?php }?>
<style type="text/css" media="screen">
.box{
height: 130px;
border-radius: 5px;
margin: 0 auto;
}
.bx-span{
font-size: 20px;
font-family: monospace;
font-weight: bolder;
text-align: center;
color: aliceblue;
}
.slogOne{
	font-size: 40px;
font-family: cursive;
font-weight: bold;
font-style: oblique;
}
.Ctrl{
	margin: 12% 0px 0px 0px;
}
.subcat{
	padding: 0px 5px 0 5px;
background-color: #ff00ff;
width: fit-content;
height: fit-content;
border-radius: 5px;
float: left;
margin: 2px 2px;
}
.subcat a{
	text-decoration: none;
color: #1e3301;
}
.fixed-bottom {
width: 100%;
background-color: lightseagreen;
color: white;
text-align: center;
padding: 25px;
font-size: 20px;
}
body {
margin: 0px;
}
</style>