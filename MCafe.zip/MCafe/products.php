<?php include('inc/header.php');?>
<?php
include 'classes/Category.php';
$cat = new Category();
?>
<?php include 'classes/Product.php';
$pro = new Product();
?>
<?php include 'classes/Order.php';
$order = new Order();
?>
<?php
include 'lib/Session.php';
Session::checkUserSession();
$tableName = Session::get("tableName");
?>
<?php
if(isset($_GET['catid'])){
$catid = $_GET['catid'];
}
?>
<?php  include 'inc/mainnav.php'; ?>
<div class="row">
	<div class="container-fluid">
		
		<?php include('inc/categoryinc.php');?>
		<div class="col-md-7" style="min-height: 480px;">
			<div class="row">
				
				<div class="section">
					<?php
					$subcats = getAllSubcatByCat($catid);
					if ($subcats) {
					while ($value = $cat->fetch_assoc()) {
					?>
					<p class="bx-span"><?php echo $value['sub_category']; ?></p>
					<?php } } ?>
				</div>
			</div>
		</div>
		<?php include('inc/orderpage.php');?>
		
	</div>
</div>
<?php include 'inc/footer.php'; ?>