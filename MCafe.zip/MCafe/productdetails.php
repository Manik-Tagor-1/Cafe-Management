<?php include('inc/header.php');?>
<?php
include 'classes/Category.php';
$cat = new Category();
?>
<?php include 'classes/Product.php';
$pro = new Product();
?>
<?php include 'classes/Order.php';
$order = new Order();
?>
<?php
include 'lib/Session.php';
Session::checkUserSession();
$tableName = Session::get("tableName");
?>
<?php
if(!isset($_GET['orderid'])){
	header("Location: index.php");
}else{
	$orderid = $_GET['orderid'];
}
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
$addCart = $order->addToCart($_POST);
}
?>
<?php include 'inc/mainnav.php'; ?>
<div class="row">
	<div class="container-fluid">
		<?php include('inc/categoryinc.php');?>
		<div class="col-md-7" style="min-height: 480px;">
			<?php
			if (isset($addCart)) {
			echo $addCart;
			}
				$pro = $pro->getSingleProduct($orderid);
				if($pro){
				while ($row = $pro->fetch_assoc()) {
			?>
			<?php $row['ProName']; ?>
			
			<form action="" method="post">
				
				<div class="table-responsive text-center">
					<table class="table table-striped table-bordered table-hover" id="dataTables-example">
						<thead>
							<tr>
								<th class="text-center" colspan="2">Product Image</th>
							</tr>
						</thead>
						<tbody>
							
							<input type="hidden" class=" col-sm-2 form-control" name="TableName" value="<?php echo $tableName; ?>"/>
							<input type="hidden" class="col-sm-2 form-control" name="ProductPrice" value="<?php echo $row['price']; ?>"/>
							<tr class="odd gradeX">
								<td class="center customcat">Product Name :</td>
								<td class="center customcat">
									<input type="text" class="col-sm-2 form-control" value="<?php echo $row['ProName']; ?>" disabled/><input type="hidden" class="col-sm-2 form-control" name="ProductName" value="<?php echo $row['ProName']; ?>"/>
								</td>
							</tr>
							<tr class="odd gradeX">
								<td class="center customcat">Product Price :</td>
								<td class="center customcat">
									<input type="text" class="col-sm-2 form-control" value="<?php echo $row['price']; ?>" disabled/>
								</td>
							</tr>
							<tr class="odd gradeX">
								<td class="center customcat">Choise Quantity :</td>
								<td class="center customcat">
									<input type="number" class="col-sm-2 form-control buyfield" name="quantity" value="1"/>
								</td>
							</tr>
							<tr class="odd gradeX">
								<td class="text-center customcat" colspan="2">
									<input type="submit" class="btn btn-info" name="submit" value="Place Order"/>
								</td>
							</tr>
						</tbody>
					</table>
				</div>
				
			</form>
			<?php } } ?>
		</div>
		<?php include('inc/orderpage.php');?>
		
	</div>
</div>
<?php include 'inc/footer.php'; ?>