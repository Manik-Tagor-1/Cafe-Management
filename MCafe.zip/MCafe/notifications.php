<?php include('inc/header.php');?>
<?php
include 'classes/Category.php';
$cat = new Category();
?>
<?php include 'classes/Product.php';
$pro = new Product();
?>
<?php include 'classes/Order.php';
$order = new Order();
?>
<?php
include 'lib/Session.php';
Session::checkUserSession();
$tableName = Session::get("tableName");
?>
<?php
if(isset($_GET['catid'])){
$catid = $_GET['catid'];
}
?>
<?php  include 'inc/mainnav.php'; ?>
<div class="row">
	<div class="container-fluid">
		
		<?php include('inc/categoryinc.php');?>
		<div class="col-md-7" style="min-height: 480px;">
			<div class="row">
				
				<script src="assets/js/jquery-3.3.1.min.js"></script>
				<script src="syotimer/jquery.syotimer.js"></script>
				<link rel="stylesheet" href="syotimer/default.css">
				<?php
				$selecttime = $pro->selecttime($tableName);
				if($selecttime){
				while ($row = $selecttime->fetch_assoc()) {
				// $countdown = "2022-06-07 16:00:00";
				$countdown = $row['datetimenow'];
				} }
				?>
				<div class="footer fixed-bottom">
					<?php if (isset($countdown)) {
						echo "Your Product will be delivered within ".$countdown." times.";
					}else{
						echo "Timer not set up for your order.";
					} ?>
				</div>
				<div id="simple_timer"></div>
				<input type="hidden" id="timer_value" value="<?php  echo $countdown; ?>">
				<script type="text/javascript">
				$(function () {
				var timer_value = document.getElementById("timer_value").value;
				var date = new Date(timer_value);
				$('#simple_timer').syotimer({
				year: date.getFullYear(),
				month: date.getMonth() + 1,
				day: date.getDate(),
				hour: date.getHours(),
				minute: date.getMinutes(),
				seconds: date.getSeconds()
				});
				});
				</script>
				<style>
				.fixed-bottom {
				width: 100%;
				background-color: lightseagreen;
				color: white;
				text-align: center;
				padding: 25px;
				font-size: 20px;
				}
				body {
				margin: 0px;
				}
				</style>
			</div>
		</div>
		<?php include('inc/orderpage.php');?>
		
	</div>
</div>
<?php include 'inc/footer.php'; ?>
<style>
	.fixed-bottom {
width: 100%;
background-color: lightseagreen;
color: white;
text-align: center;
padding: 25px;
font-size: 20px;
}
body {
margin: 0px;
}
</style>