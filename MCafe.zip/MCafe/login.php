<?php
include 'classes/User.php';
$user = new User();
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['userlogin'])){
$loginChk = $user->usersLogin($_POST);
}
?>
<?php include('inc/header.php'); ?>
<body>
    <!------MENU SECTION START-->
    
    <section class="menu-section">
        <div class="container">
            <div class="row ">
                <div class="col-md-12">
                    
                    <div class="navbar-collapse collapse "> <!--  Just Design -->  </div>
                </div>
            </div>
        </div>
    </section>
    <!-- MENU SECTION END-->
    <div class="container">
        <div class="row pad-botm">
            <div class="col-md-12 text-center">
                <h4 class="header-line">USER LOGIN FORM</h4>
            </div>
        </div>
        
        
        <!--LOGIN PANEL START-->
        <div class="row">
            <div class="col-md-6 col-sm-6 col-xs-12 col-md-offset-3" >
                <div class="panel panel-info">
                    <div class="panel-heading">
                        User Login Form
                    </div>
                    <div class="panel-body">
                        <?php if (isset($loginChk)) {
                            echo $loginChk;
                        } ?>
                        <form role="form" method="post">
                            <div class="form-group">
                                <label>Enter Table Name</label>
                                <input class="form-control" type="text" name="tableName"/>
                            </div>
                            <div class="form-group">
                                <label>Password</label>
                                <input class="form-control" type="password" name="password"/>
                            </div>
                            <!-- <div class="form-group">
                                <label>Verification code: </label>
                                <input type="text"  name="vercode" maxlength="5" autocomplete="off" required style="width: 150px; height: 25px;" />&nbsp;<img src="captcha.php">
                            </div> -->
                            <button type="submit" name="userlogin" class="btn btn-info">LOGIN </button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
        <!---LOGIN PABNEL END-->
        
        
    </div>
    <!-- CONTENT-WRAPPER SECTION END-->
    <?php include('inc/footer.php');?>